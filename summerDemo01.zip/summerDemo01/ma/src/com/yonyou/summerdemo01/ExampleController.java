package com.yonyou.summerdemo01;

import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import com.yonyou.uap.um.context.util.UmContextUtil;
import com.yonyou.uap.um.gateway.service.GatewayServiceFactory;
import com.yonyou.uap.um.gateway.service.IGatewayService;
import com.yonyou.uap.um.utils.MALogger;

public class ExampleController {
	public String getData(String args) throws Exception {
		MALogger.info("发起ma请求，getData *******************");
		JSONArray jsonArray = new JSONArray();
		String sender ="";
		String img = "";
		String lastMsg = "";
		
		for(int i = 0; i < 10; i++ ) {
			JSONObject json = new JSONObject();
			int k = i%3;
			switch(k) {
			case 0: 
				sender = "华新丽华移动培训进度跟踪";
				lastMsg = "进过两天的移动培训，大家对移动开发有了初步了解";
				break;
			case 1: 
				sender = "华新丽华IT部";
				lastMsg = "移动需求旺盛，待加强开发进度";
				break;
			case 2: 
				sender = "华新丽华运营部";
				lastMsg = "经过测试，后台性能可以进一步提升";
				break;
			}
			img = "../img/org"+k+".png";
			json.put("sender", sender);
			json.put("img", img);
			json.put("msgNum", k);
			json.put("lastTime", "10:18");
			jsonArray.put(json);
		}
		return jsonArray.toString();
	}
	
	public String getName(String args) throws Exception {
		
		return commonMethod(args,"getNameServiceID");
	}
	
	// 正常调用后台业务逻辑		 
	public String commonMethod(String args, String serviceid) throws Exception {
		JSONObject json = new JSONObject(args);
		Map<String, String> map = UmContextUtil.transJsonToMap(json);
		String appid = map.get("appid");
		//map.put("age", "10");
		IGatewayService service = GatewayServiceFactory.findGatewayService(appid, serviceid, map);
		return (String)service.doService();	 
	}
}






