﻿var vue = new Vue({
	el : "#index",
	data : {
		name : "帅小伙儿",
		userIcon : "../img/user.png"
	},
	methods : {
		changeIcon : function() {
			//console.log("changeIcon...");
			UM.actionsheet({
				title : '选择照片',
				items : ['从图库中选择', '照相'],
				callbacks : [
				function() {
					//alert('图库')
					summer.openPhotoAlbum({
						callback : function(args) {
							/*summer.toast({
							 msg : args.imgPath
							 });*/
							vue.userIcon = args.imgPath;
						}
					});
				},
				function() {
					// 1. 申请权限
					summer.getPermission(["android.permission.CAMERA", "android.permission.READ_PHONE_STATE", "android.permission.WRITE_EXTERNAL_STORAGE"], function() {
					}, function() {
					})
					// 2. 打开相机
					// alert('照相')
					summer.openCamera({
						callback : function(args) {
							vue.userIcon = args.imgPath;
						}
					});
				}]

			});
		},
		goHome : function() {

		}
	},
	mounted : function() {
		// 1.获取数据
		// 2.给data里面监听的数据对象赋值
		this.name = "个人中心";

	}
});
