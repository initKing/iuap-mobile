﻿/*
var jsonArray = [{
"sender" : "集团IT服务台",
"img" : "../img/org1.png",
"msgNum" : 0,
"lastMsg" : "因无线网络后台故障，暂停服务。",
"lastTime" : "15:24"
}, {
"sender" : "集团行政部",
"img" : "../img/org2.png",
"msgNum" : 4,
"lastMsg" : "各位同仁，2015年4季度油料报销标准5.85元/升。",
"lastTime" : "12:40"
}, {
"sender" : "集团人力资源部",
"img" : "../img/org3.png",
"msgNum" : 5,
"lastMsg" : "各位同仁，跟据国务院发布的放假安排，2016年元旦、春节放假安排如下。",
"lastTime" : "12:21"
}];
*/

// 构造控件Vue实例
var vue = new Vue({
	el : '#listview',
	data : {
		listDatas : [],
		timeOutEvent : 0
	},
	mounted : function() {
		// 组件挂载后执行...

		// 0. 申请权限
		summer.getPermission(["android.permission.READ_PHONE_STATE", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"], function() {
		}, function() {
		})
		// 1.指定Ma服务的地址
		summer.writeConfig({
			"host" : MA_IP, //MA主机地址
			"port" : MA_PORT //MA主机端口
		});

		// 2. 向Ma Server 发起请求，并传递参数
		summer.callAction({
			"appid" : "summerDemo01", //当前应用id，即config.xml配置文件中的应用ID
			"viewid" : "com.yonyou.summerdemo01.ExampleController", //后台带包名的Controller名 java 类
			"action" : "getData", //上述java类里的方法名
			"params" : {
				name : "小伙儿",
				"city" : "台北"
			}, //自定义参数 是给getData传递的参数，需要在serverces.xml文件中配置
			"callback" : "mycallback()", //请求回来后执行的js方法
			"error" : "myerror()" //失败回调的js方法
		});
		//this.listDatas = jsonArray;
	},
	methods : {
		/* 在这里定义方法 */
		itemClick : function(index) {
			// 这里编辑单击列表项逻辑
			alert("您点击了列表第" + (index + 1) + "行！");
		},
		tapHold : function(index) {
			// 这里编辑长按列表项逻辑
			var ev = event || window.event;
			var touches = ev.targetTouches;
			if (touches.length > 1) {
				return;
			}
			this.timeOutEvent = setTimeout(function() {
				this.timeOutEvent = 0;
				alert("您长按了列表第" + (index + 1) + "行！");
			}, 2000);
		},
		cancelTapHold : function() {
			// 取消长按
			clearTimeout(this.timeOutEvent);
			this.timeOutEvent = 0;
		},
		deleteItem : function(index) {
			// 这里编辑删除列表项逻辑
			this.listDatas.splice(index, 1);
		},
		loadTop : function() {
			// 这里编辑下拉刷新逻辑
			var self = this;
			setTimeout(function() {
				var row = {
					"sender" : "集团技术部",
					"img" : "../img/org4.png",
					"msgNum" : 2,
					"lastMsg" : "各位同仁，2015年4季度油料报销标准5.85元/升。",
					"lastTime" : "16:22",
				};
				self.listDatas.unshift(row);
				self.$refs.loadmore.onTopLoaded();
			}, 2000);
		},
		loadBottom : function() {
			// 这里编辑上拉加载逻辑
			var self = this;
			setTimeout(function() {
				var row = {
					"sender" : "集团咨询部",
					"img" : "../img/org5.png",
					"msgNum" : 6,
					"lastMsg" : "各位同仁，2015年4季度油料报销标准5.85元/升。",
					"lastTime" : "12月22日"
				};
				self.listDatas.push(row);
				self.$refs.loadmore.onBottomLoaded();
			}, 2000);
		}
	}
});

// 需要实现成功回调和失败回调
function mycallback(args) {
	alert("成功回调：\n"+ JSON.stringify(args));
	console.log("成功回调： \n"+JSON.stringify(args));
}

function myerror(args) {
	alert("失败回调：\n"+ JSON.stringify(args));
	console.log("失败回调： \n"+JSON.stringify(args));
}