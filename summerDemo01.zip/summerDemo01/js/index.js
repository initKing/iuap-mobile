﻿summerready = function() {
	// here is your code...

	var top = $summer.offset($summer.byId('header')).h;
	var bottom = $summer.offset($summer.byId('footer')).h;

	summer.openFrame({
		id : 'main',
		url : 'html/main.html',
		bounces : true,
		position : {
			top : top,
			bottom : bottom,
			left : 0,
			right : 0
		}
	});
}
var vue = new Vue({
	el : "#win",
	data : {

	},
	methods : {
		openFrame : function(frameid) {
			console.log("打开"+frameid);   
			var top = $summer.offset($summer.byId('header')).h;
			var bottom = $summer.offset($summer.byId('footer')).h;
			summer.openFrame({
				id : frameid,
				url : 'html/'+ frameid +'.html',
				bounces : true,
				position : {
					top : top,
					bottom : bottom,
					left : 0,
					right : 0
				}
			});
		}
	}
}); 